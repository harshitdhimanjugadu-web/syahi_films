/* SYAHI FILMS: central configuration. Edit here only. */
window.SYAHI={
  name:'SYAHI FILMS',
  url:'https://syahi-films.netlify.app/',
  contact:{
    email:'hoodstudio1@gmail.com',
    whatsapp:[{label:'+91 7739363798',number:'917739363798'},{label:'+91 90060 49471',number:'919006049471'}]
  },
  /* shape: 'tall' = 9:16 cards, 'wide' = 16:9 cards. Each category shows up to 5 projects. */
  categories:[
    {id:'reels',label:'Reels',shape:'tall'},{id:'shorts',label:'Shorts',shape:'tall'},
    {id:'youtube',label:'YouTube',shape:'wide'},{id:'motion',label:'Motion Graphics',shape:'wide'},
    {id:'typography',label:'Typography',shape:'wide'},{id:'commercial',label:'Commercial & Ads',shape:'tall'},
    {id:'amv',label:'AMV',shape:'wide'},{id:'thumbnails',label:'Thumbnails',shape:'wide'}
  ],
  perCategory:5,
  budgets:['Not sure yet','Under ₹5,000','₹5,000 - ₹15,000','₹15,000 - ₹50,000','₹50,000+'], /* edit to match your pricing */
  form:{endpoint:'',accessKey:'',allowUpload:false,maxFileMB:10}, /* endpoint: Formspree or Web3Forms URL. Empty = WhatsApp fallback */
  analytics:{provider:'',site:''}, /* 'plausible' + domain, or 'goatcounter' + your code. Empty = off */
  hero:{video:'assets/video/Trial.mp4',mobileVideo:'',poster:''},
  social:[], /* e.g. [{label:'Instagram',url:'https://instagram.com/yourhandle'}]; footer hides this column until filled */
  content:'data/content.json'
};
