(()=>{const C=window.SYAHI;if(!C)return;document.querySelectorAll('[data-c=mail]').forEach(a=>{a.href='mailto:'+C.contact.email;a.textContent=C.contact.email})})();
