(()=>{'use strict';
const C=window.SYAHI,q=s=>document.querySelector(s),qa=s=>[...document.querySelectorAll(s)];
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const catLabel=id=>(C.categories.find(c=>c.id===id)||{label:id}).label;
const dnt=navigator.doNotTrack==='1'||window.doNotTrack==='1';

/* analytics: off unless configured, respects Do Not Track, no personal data sent */
const A=C.analytics||{};
function track(n,p){try{if(dnt||!A.provider)return;
 if(A.provider==='plausible'&&window.plausible)window.plausible(n,{props:p||{}});
 else if(A.provider==='goatcounter'&&window.goatcounter&&window.goatcounter.count)window.goatcounter.count({path:'event/'+n,title:n,event:true})}catch(e){}}
if(A.provider&&A.site&&!dnt){const s=document.createElement('script');s.defer=true;
 if(A.provider==='plausible'){s.dataset.domain=A.site;s.src='https://plausible.io/js/script.js';window.plausible=window.plausible||function(){(window.plausible.q=window.plausible.q||[]).push(arguments)}}
 else{s.dataset.goatcounter='https://'+A.site+'.goatcounter.com/count';s.src='https://gc.zgo.at/count.js'}
 document.head.append(s)}

/* contact links from config */
const W=C.contact.whatsapp,M=C.contact.email;
const wa=(n,t)=>'https://wa.me/'+n+'?text='+encodeURIComponent(t||"Hi SYAHI FILMS, I'd like to discuss a video editing project.");
qa('[data-c]').forEach(a=>{const k=a.dataset.c;
 if(k==='wa1'||k==='wa2'){const w=W[k==='wa1'?0:1];if(!w){a.hidden=true;return}a.href=wa(w.number);a.target='_blank';a.rel='noopener noreferrer';if(a.closest('.contact'))a.textContent='WhatsApp '+w.label}
 else if(k==='mail'){a.href='mailto:'+M;if(a.closest('.contact'))a.textContent='Email '+M;else if(a.closest('.foot'))a.textContent=M}});
document.addEventListener('click',e=>{const a=e.target.closest('[data-c]');if(a)track(a.dataset.c==='mail'?'email_click':'whatsapp_click',{where:(a.closest('section,footer,header')||{}).id||'page'})});

const so=C.social||[],sn=q('#social');if(sn){so.forEach(s=>{const x=el('a','',s.label);x.href=s.url;x.target='_blank';x.rel='noopener noreferrer';sn.append(x)});if(!so.length)sn.parentElement.hidden=true}
/* hero video: skipped on reduced motion, Save-Data, slow networks */
(()=>{const H=C.hero||{},v=q('.hv');if(!v||!H.video)return;const cn=navigator.connection||{};
 if(matchMedia('(prefers-reduced-motion:reduce)').matches||cn.saveData||/2g/.test(cn.effectiveType||''))return;
 if(H.poster){v.poster=H.poster;v.classList.add('ready')}
 v.addEventListener('error',()=>v.remove(),{once:true});v.addEventListener('loadeddata',()=>v.classList.add('ready'));
 v.src=(matchMedia('(max-width:700px)').matches&&H.mobileVideo)||H.video;v.play().catch(()=>{})})();

/* offline banner + menu Esc */
const net=q('#net'),sync=()=>{net.hidden=navigator.onLine};addEventListener('online',sync);addEventListener('offline',sync);sync();

/* portfolio: one row per category, up to 5 projects each */
let cur='all';
const srcs=(v,p)=>{if(p.webm){const s=el('source');s.src=p.webm;s.type='video/webm';v.append(s)}const s2=el('source');s2.src=p.video;s2.type='video/mp4';v.append(s2)};
function apply(){qa('.cat').forEach(s=>{s.hidden=cur!=='all'&&s.dataset.c!==cur})}
function filters(){const f=q('.filters');const mk=(id,l)=>{const b=el('button',id==='all'?'on':'',l);b.type='button';b.dataset.f=id;b.setAttribute('aria-pressed',id==='all');return b};
 f.append(mk('all','All'),...C.categories.map(c=>mk(c.id,c.label)));
 f.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;cur=b.dataset.f;qa('.filters button').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)});apply()})}
function card(p){const a=el('article','reel'+(p.poster?'':' nomedia'));a.tabIndex=0;a.dataset.c=p.category;a.setAttribute('role','button');a.setAttribute('aria-label','View project: '+p.title);
 if(p.poster){const im=new Image();im.src=p.poster;im.alt=p.title+' ('+catLabel(p.category)+')';im.loading='lazy';im.decoding='async';a.append(im)}else a.append(el('div','ph',p.title));
 if(p.video)a.append(el('div','play'));
 const m=el('div','meta');m.append(el('b','',p.title));a.append(m);
 let v;
 if(p.video&&matchMedia('(hover:hover)').matches){
  a.addEventListener('pointerenter',()=>{if(!v){v=document.createElement('video');v.muted=true;v.loop=true;v.playsInline=true;v.preload='metadata';v.setAttribute('aria-hidden','true');srcs(v,p);a.append(v)}v.play().catch(()=>{});a.classList.add('playing')});
  a.addEventListener('pointerleave',()=>{if(v)v.pause();a.classList.remove('playing')})}
 const go=()=>open(p,a);a.addEventListener('click',go);a.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}});
 return a}
function grid(list,failed){const box=q('#reels'),n=C.perCategory||5;box.replaceChildren();
 const e=q('#empty');if(failed){e.textContent='Portfolio could not be loaded. Please refresh the page.';e.hidden=false}
 C.categories.forEach(c=>{const items=list.filter(p=>p.category===c.id).slice(0,n);
  const sec=el('div','cat');sec.dataset.c=c.id;
  const h=el('div','cat-h');h.append(el('h3','',c.label),el('span','',String(items.length).padStart(2,'0')+' / '+String(n).padStart(2,'0')));
  const row=el('div','row5'+(c.shape==='wide'?' wide':''));
  items.forEach(p=>row.append(card(p)));
  for(let i=items.length;i<n;i++){const s=el('div','reel soon');s.setAttribute('aria-hidden','true');s.append(el('div','ph','Coming soon'));row.append(s)}
  sec.append(h,row);box.append(sec)});
 apply()}

/* lightbox */
const lb=q('#lb');let last;
function open(p,from){last=from;const m=q('#lbm');m.replaceChildren();
 if(p.video){const v=document.createElement('video');v.controls=true;v.playsInline=true;v.preload='metadata';if(p.poster)v.poster=p.poster;srcs(v,p);m.append(v);v.play().catch(()=>{})}
 else if(p.image||p.poster){const im=new Image();im.src=p.image||p.poster;im.alt=p.title;m.append(im)}
 q('#lbt').textContent=p.title;
 q('#lbd').textContent=[[catLabel(p.category),p.client,p.year].filter(Boolean).join(' • '),p.description,(p.tools&&p.tools.length)?'Tools: '+p.tools.join(', '):''].filter(Boolean).join('\n');
 lb.classList.add('open');lb.querySelector('button').focus();document.body.style.overflow='hidden';track('portfolio_view',{project:p.title,category:p.category})}
function close(){if(!lb.classList.contains('open'))return;lb.classList.remove('open');q('#lbm').replaceChildren();document.body.style.overflow='';if(last)last.focus()}
lb.addEventListener('click',e=>{if(e.target===lb||e.target.closest('button,a'))close()});
addEventListener('keydown',e=>{
 if(e.key==='Escape'){close();q('#links').classList.remove('open');q('#burger').setAttribute('aria-expanded','false')}
 if(e.key==='Tab'&&lb.classList.contains('open')){const f=[...lb.querySelectorAll('button,a[href],video[controls]')];if(!f.length)return;const i=f.indexOf(document.activeElement);
  if(e.shiftKey&&i<=0){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&i===f.length-1){e.preventDefault();f[0].focus()}}});

/* optional sections: shown only when real data exists */
function show(id,list,fn){if(!list||!list.length)return;const s=q('#'+id),b=s.querySelector('.grid');list.forEach(x=>b.append(fn(x)));s.hidden=false}
function extras(d){
 show('reviews',d.testimonials,t=>{const c=el('div','card');c.append(el('p','qt','“'+t.quote+'”'),el('h3','',t.name));if(t.role)c.append(el('p','',t.role));return c});
 show('cases',d.cases,x=>{const c=el('div','card');c.append(el('h3','',x.title));if(x.category)c.append(el('p','',catLabel(x.category)));if(x.summary)c.append(el('p','',x.summary));if(x.result)c.append(el('p','','Result: '+x.result));return c});
 show('trust',d.trust,t=>{const c=el('div','card');c.append(el('b','statv',t.value),el('p','',t.label));return c});
 if(d.about||(d.team&&d.team.length)){const s=q('#about');if(d.about)s.querySelector('.abt').textContent=d.about;
  show('about',d.team,m=>{const c=el('div','card');c.append(el('h3','',m.name),el('p','',m.role||''));if(m.bio)c.append(el('p','',m.bio));return c});s.hidden=false}}
const empty={projects:[],testimonials:[],cases:[],team:[],about:'',trust:[]};
filters();
fetch(C.content).then(r=>{if(!r.ok)throw 0;return r.json()}).then(d=>{d={...empty,...d};grid(d.projects);extras(d)}).catch(()=>grid([],true));

/* inquiry form */
const F=q('#f'),inputs={};
const D={name:['Name','text',1],email:['Email','email',1],wa:['WhatsApp number','tel',0],type:['Project type','select',1],budget:['Budget','select',0],deadline:['Deadline','date',0],ref:['Reference link (Drive, YouTube, etc.)','url',0],message:['Project details','textarea',1],file:['Reference file (optional, max '+(C.form.maxFileMB||10)+' MB)','file',0]};
function field(id){const [l,t,req]=D[id],w=el('div','fld'),lab=el('label','',l+(req?' *':''));lab.htmlFor='f-'+id;let i;
 if(t==='select'){i=document.createElement('select');(id==='type'?['',...C.categories.map(c=>c.label),'Other']:C.budgets).forEach(o=>{const p=el('option','',o||'Select project type');p.value=o;i.append(p)})}
 else if(t==='textarea'){i=document.createElement('textarea');i.rows=5;i.maxLength=2000}
 else{i=document.createElement('input');i.type=t;if(t==='tel')i.inputMode='tel';if(t==='date')i.min=new Date().toISOString().slice(0,10);if(t==='file')i.accept='.mp4,.mov,.zip,.jpg,.jpeg,.png,.pdf';if(id==='name')i.maxLength=80}
 i.id='f-'+id;i.name=id;const er=el('span','err');er.id='e-'+id;er.setAttribute('role','alert');i.setAttribute('aria-describedby',er.id);
 if(id==='name')i.autocomplete='name';if(id==='email')i.autocomplete='email';if(id==='wa')i.autocomplete='tel';
 inputs[id]=i;w.append(lab,i,er);return w}
const row=(...x)=>{const r=el('div','row');r.append(...x);return r};
F.append(row(field('name'),field('email')),row(field('wa'),field('type')),row(field('budget'),field('deadline')),field('ref'),field('message'));
if(C.form.allowUpload)F.append(field('file'));
const hp=el('div','hp');hp.setAttribute('aria-hidden','true');const hi=document.createElement('input');hi.name='company_site';hi.tabIndex=-1;hi.autocomplete='off';hp.append(hi);
const sb=el('button','btn fill','Send inquiry');sb.type='submit';
const fs=el('div');fs.id='fs';fs.setAttribute('role','status');fs.setAttribute('aria-live','polite');fs.hidden=true;
const pn=el('small','','By sending, you agree to our ');const pl=el('a','','Privacy Policy');pl.href='legal/privacy.html';pn.append(pl,'.');
F.append(hp,sb,fs,pn);
const say=(m,k)=>{fs.hidden=false;fs.className=k;fs.textContent=m};
const val=id=>inputs[id].value.trim();
const err=(id,m)=>{q('#e-'+id).textContent=m||'';inputs[id].setAttribute('aria-invalid',!!m)};
function valid(){let ok=true,first;const set=(id,m)=>{err(id,m);if(m){ok=false;first=first||inputs[id]}};
 set('name',val('name').length<2?'Enter your name.':'');
 set('email',/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val('email'))?'':'Enter a valid email address.');
 set('wa',val('wa')&&!/^\+?[\d\s-]{8,16}$/.test(val('wa'))?'Enter a valid number with country code.':'');
 set('type',val('type')?'':'Choose a project type.');
 set('message',val('message').length<10?'Tell us a little more (at least 10 characters).':'');
 let r='';if(val('ref')){try{if(!/^https?:$/.test(new URL(val('ref')).protocol))throw 0}catch(e){r='Enter a full link starting with https://'}}set('ref',r);
 set('deadline',val('deadline')&&val('deadline')<inputs.deadline.min?'Deadline cannot be in the past.':'');
 if(inputs.file){const f=inputs.file.files[0];set('file',f&&f.size>C.form.maxFileMB*1048576?'File is too large.':'')}
 if(first)first.focus();return ok}
let lock=0;
F.addEventListener('submit',async e=>{e.preventDefault();if(Date.now()<lock||!valid())return;
 if(hi.value)return say('Thank you! We will get back to you soon.','ok');
 const ty=val('type'),text=`Hi SYAHI FILMS, I'm ${val('name')}.\nProject: ${ty}\nBudget: ${val('budget')||'-'}\nDeadline: ${val('deadline')||'-'}\nReference: ${val('ref')||'-'}\nEmail: ${val('email')}\n\n${val('message')}`;
 if(!navigator.onLine)return say('You appear to be offline. Reconnect and try again, or use the WhatsApp button above.','bad');
 if(!C.form.endpoint){track('inquiry_submit',{type:ty,via:'whatsapp'});say('Opening WhatsApp with your details…','ok');if(W[0])window.open(wa(W[0].number,text),'_blank','noopener');return}
 sb.disabled=true;sb.textContent='Sending…';const ac=new AbortController(),to=setTimeout(()=>ac.abort(),20000);
 try{const fd=new FormData(F);fd.delete('company_site');if(C.form.accessKey)fd.append('access_key',C.form.accessKey);fd.append('subject','New inquiry: '+ty+' - '+val('name'));
  const r=await fetch(C.form.endpoint,{method:'POST',body:fd,headers:{Accept:'application/json'},signal:ac.signal});if(!r.ok)throw new Error(r.status);
  F.reset();say('Thank you! Your inquiry was sent. We will reply on WhatsApp or email.','ok');track('inquiry_submit',{type:ty});if(window.confetti)window.confetti();lock=Date.now()+30000}
 catch(x){track('inquiry_error');say('Could not send your inquiry. Please try again, or use the WhatsApp button above.','bad')}
 finally{clearTimeout(to);sb.disabled=false;sb.textContent='Send inquiry'}});
})();
