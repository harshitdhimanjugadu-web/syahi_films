/* Cinematic motion layer. Transform/opacity only; every effect respects reduced motion. */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
function split(el){const t=el.textContent.trim(),f=document.createDocumentFragment();el.setAttribute('aria-label',t);
 t.split(/\s+/).forEach((w,i)=>{const o=document.createElement('span'),s=document.createElement('span');o.className='w';o.setAttribute('aria-hidden','true');s.style.setProperty('--i',i);s.textContent=w;o.append(s);f.append(o,' ')});el.replaceChildren(f)}
$$('[data-split]').forEach(split);const sc=$$('.scrub');sc.forEach(split);

/* loader -> hero reveal */
let done=false;const ready=()=>{if(done)return;done=true;const l=$('#loader');if(l){l.classList.add('gone');setTimeout(()=>l.remove(),1500)}
 setTimeout(()=>$$('.hero [data-split]').forEach(e=>e.classList.add('in')),RM?0:500)};
addEventListener('load',()=>setTimeout(ready,600));setTimeout(ready,3500);

/* reveal on view */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
$$('[data-split]:not(.hero *),.rv').forEach(e=>io.observe(e));
if(RM)sc.forEach(e=>e.querySelectorAll('.w').forEach(w=>w.classList.add('on')));

/* hero timecode + waveform (visual rhythm only, no audio) */
const wave=$('#wave');if(wave)for(let i=0;i<30;i++){const b=document.createElement('i');b.style.setProperty('--d',(.6+Math.random()*1.1).toFixed(2)+'s');b.style.setProperty('--dl',(-Math.random()*2).toFixed(2)+'s');wave.append(b)}
const tc=$('#tc');if(tc&&!RM){const t0=performance.now(),p=n=>String(n|0).padStart(2,'0');setInterval(()=>{const s=(performance.now()-t0)/1000;tc.textContent=`${p(s/3600)}:${p(s/60%60)}:${p(s%60)}:${p(s%1*24)}`},80)}

/* services accordion + color shift */
const rows=$$('.srow');rows.forEach(r=>{const b=r.querySelector('button');
 const set=o=>{rows.forEach(x=>{const on=x===r&&o;x.classList.toggle('open',on);x.querySelector('button').setAttribute('aria-expanded',on)});if(o)$('.svc').style.setProperty('--tint',r.dataset.t)};
 b.addEventListener('click',()=>set(!r.classList.contains('open')));
 if(matchMedia('(hover:hover)').matches)r.addEventListener('pointerenter',()=>set(true))});
if(rows[0])rows[0].querySelector('button').click();

/* horizontal selected work (desktop pinned, mobile native snap) */
const wk=$('#work'),tr=$('#reels'),wb=$('#wbar'),mq={matches:false};
const dist=()=>Math.max(0,tr.scrollWidth-innerWidth);
function hp(){if(!mq.matches){tr.style.transform='';return}const t=wk.offsetHeight-innerHeight,p=t>0?Math.min(Math.max((scrollY-wk.offsetTop)/t,0),1):0;tr.style.transform=`translate3d(${-p*dist()}px,0,0)`;wb.style.transform=`scaleX(${p})`}
function hs(){wk.style.height=mq.matches?dist()+innerHeight+'px':'';hp()}
addEventListener('resize',hs);addEventListener('load',hs);

/* one rAF-throttled scroll frame */
const nav=$('#nav'),hv=$('.hv'),secs=$$('main section[id]'),lk=$$('.links a[href^="#"]:not(.pill)');
function frame(){nav.classList.toggle('s',scrollY>50);
 if(hv&&!RM&&scrollY<innerHeight)hv.style.transform=`translate3d(0,${scrollY*.12}px,0) scale(1.04)`;
 if(!RM)sc.forEach(el=>{const r=el.getBoundingClientRect(),ws=el.querySelectorAll('.w'),p=Math.min(Math.max((innerHeight*.85-r.top)/(r.height+innerHeight*.35),0),1),n=Math.round(p*ws.length);ws.forEach((w,i)=>w.classList.toggle('on',i<n))});
 hp();let c='';secs.forEach(s=>{if(scrollY>=s.offsetTop-260)c=s.id});lk.forEach(a=>a.classList.toggle('on',a.hash==='#'+c))}
let tk=false;addEventListener('scroll',()=>{if(!tk){tk=true;requestAnimationFrame(()=>{tk=false;frame()})}},{passive:true});frame();

/* smooth scroll */
let lenis=null;
if(window.Lenis&&!RM){lenis=new Lenis({lerp:.085});document.documentElement.classList.add('lenis');(function r(t){lenis.raf(t);requestAnimationFrame(r)})(0)}
$$('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const el=$(a.hash);if(!el)return;e.preventDefault();lenis?lenis.scrollTo(a.hash==='#top'?0:el):el.scrollIntoView({behavior:'smooth'});$('#links').classList.remove('open');$('#burger').setAttribute('aria-expanded','false')}));
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('open');$('#burger').setAttribute('aria-expanded',o)};

$('#yr').textContent=new Date().getFullYear();
if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('sw.js').catch(()=>{});

/* colourful floating embers */
if(!RM){const cv=document.createElement('canvas');cv.id='embers';cv.setAttribute('aria-hidden','true');document.body.append(cv);
 const x=cv.getContext('2d'),dpr=Math.min(devicePixelRatio||1,2),hues=[40,30,22,14,6,350,45];let W,H,P=[],run=true;
 const N=()=>innerWidth<768?55:110;
 const mk=i=>{const up=Math.random()<.88;return{x:Math.random()*W,y:i?Math.random()*H:(up?H+10:-10),s:Math.random()*2.2+.5,v:(Math.random()*.6+.2)*(up?-1:1),d:(Math.random()-.5)*.4,a:Math.random()*.5+.35,f:Math.random()*6.3,h:hues[Math.random()*hues.length|0]}};
 const rs=()=>{W=innerWidth;H=innerHeight;cv.width=W*dpr;cv.height=H*dpr;cv.style.width=W+'px';cv.style.height=H+'px';x.setTransform(dpr,0,0,dpr,0,0);P=Array.from({length:N()},()=>mk(1))};
 rs();let rt;addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(rs,200)});
 document.addEventListener('visibilitychange',()=>{run=!document.hidden;if(run)requestAnimationFrame(loop)});
 function loop(){if(!run)return;x.clearRect(0,0,W,H);x.globalCompositeOperation='lighter';
  P.forEach((p,i)=>{p.y+=p.v;p.f+=.03;p.x+=p.d+Math.sin(p.f)*.2;const al=p.a*(.6+Math.sin(p.f)*.4);
   const g=x.createRadialGradient(p.x,p.y,0,p.x,p.y,p.s*5);g.addColorStop(0,`hsla(${p.h},100%,70%,${al})`);g.addColorStop(1,`hsla(${p.h},100%,55%,0)`);
   x.fillStyle=g;x.beginPath();x.arc(p.x,p.y,p.s*5,0,6.3);x.fill();
   if(p.y<-20||p.y>H+20)P[i]=mk(0)});
  requestAnimationFrame(loop)}
 requestAnimationFrame(loop)}

/* video-editor timeline in the background (static markup, only the playhead moves) */
(()=>{const t=document.createElement('div');t.className='nle';t.setAttribute('aria-hidden','true');
 const tracks=[['V3',[[6,14,'c4'],[46,18,'c1'],[80,14,'c5']]],['V2',[[0,22,'c2'],[27,17,'c3'],[62,26,'c5']]],['V1',[[0,33,'c1'],[34,29,'c2'],[64,36,'c3']]],['A1',[[0,52,'au'],[53,47,'au']]],['A2',[[9,38,'au2'],[58,34,'au2']]]];
 const p=n=>String(n).padStart(2,'0');
 let h='<div class="nle-bar"><i></i><i></i><i></i><span>SYAHI_FILMS_Final_Cut.prproj</span></div><div class="nle-ruler">'+Array.from({length:8},(_,i)=>`<span style="left:${i*12.5}%">00:00:${p(i*4)}:00</span>`).join('')+'</div><div class="nle-body">';
 tracks.forEach(([n,cl])=>{h+=`<div class="nle-tr"><b>${n}</b><div class="nle-lane">`+cl.map(([l,w,c])=>`<i class="${c}" style="left:${l}%;width:${w}%"></i>`).join('')+'</div></div>'});
 h+='<div class="nle-ph"></div></div>';t.innerHTML=h;const f=document.querySelector('.fire');f?f.before(t):document.body.prepend(t)})();
